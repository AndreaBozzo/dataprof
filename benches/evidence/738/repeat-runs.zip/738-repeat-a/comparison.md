Reference: pandas. Different workloads; metric equivalence is not established.
Cold = fresh process (startup/import/exit included); warm = operation after warmup.
Times in seconds: median [IQR]. Cache treatment is recorded in results.json.
Evidence: diagnostic; 2 process blocks, 7 samples per block. Publication mode is not an established baseline.
Import/setup and first-operation boundaries and ordered controls are retained in JSON; no independent medians are subtracted.

| Tool | Cold median [IQR] | Warm median [IQR] | Cold vs reference | Warm vs reference |
| --- | ---: | ---: | --- | --- |
| dataprof | 0.331729 [0.113846] | 0.046951 [0.018502] | 2.77x speedup | 8.16x slowdown |
| pandas | 0.917569 [0.110147] | 0.005757 [0.003465] | 1.00x speedup | 1.00x speedup |
| polars | 0.609879 [0.188020] | 0.001451 [0.000148] | 1.50x speedup | 3.97x speedup |
| ydata-profiling | 5.474194 [1.876034] | 0.213707 [0.019736] | 5.97x slowdown | 37.12x slowdown |
