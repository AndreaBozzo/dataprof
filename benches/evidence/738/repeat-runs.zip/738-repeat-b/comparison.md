Reference: pandas. Different workloads; metric equivalence is not established.
Cold = fresh process (startup/import/exit included); warm = operation after warmup.
Times in seconds: median [IQR]. Cache treatment is recorded in results.json.
Evidence: diagnostic; 2 process blocks, 7 samples per block. Publication mode is not an established baseline.
Import/setup and first-operation boundaries and ordered controls are retained in JSON; no independent medians are subtracted.

| Tool | Cold median [IQR] | Warm median [IQR] | Cold vs reference | Warm vs reference |
| --- | ---: | ---: | --- | --- |
| dataprof | 0.295872 [0.092826] | 0.038788 [0.041055] | 2.73x speedup | 5.59x slowdown |
| pandas | 0.808065 [0.253788] | 0.006944 [0.003352] | 1.00x speedup | 1.00x speedup |
| polars | 0.590418 [0.187031] | 0.001869 [0.003914] | 1.37x speedup | 3.72x speedup |
| ydata-profiling | 5.105104 [0.518688] | 0.244650 [0.044581] | 6.32x slowdown | 35.23x slowdown |

Repeat-run IQR overlap (diagnostic, not a confidence interval):
- dataprof: cold overlaps, warm overlaps
- pandas: cold overlaps, warm overlaps
- polars: cold overlaps, warm overlaps
- ydata-profiling: cold overlaps, warm overlaps
